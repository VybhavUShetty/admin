package com.lti.springMvcCrud.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Trainee45")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="person-seq")
	@SequenceGenerator(name="person-seq",sequenceName="per_seq",allocationSize=1)
	private long id;
	private String user_name;
	private String training_name;
	private String training_location;

	private String status;
	public User(long id, String user_name, String training_name, String training_location, String status) {
		super();
		this.id = id;
		this.user_name = user_name;
		this.training_name = training_name;
		this.training_location = training_location;
		this.status = status;
	}
	public User() {
		super();
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getTraining_name() {
		return training_name;
	}
	public void setTraining_name(String training_name) {
		this.training_name = training_name;
	}
	public String getTraining_location() {
		return training_location;
	}
	public void setTraining_location(String training_location) {
		this.training_location = training_location;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", user_name=" + user_name + ", training_name=" + training_name
				+ ", training_location=" + training_location + ", status=" + status + "]";
	}

	

}